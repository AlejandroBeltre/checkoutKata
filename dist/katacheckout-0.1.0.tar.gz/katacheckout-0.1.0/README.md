# Checkout package

Este proyecto es con el fin de adaptar la [Kata 09: Back to the Checkout](http://codekata.com/kata/kata09-back-to-the-checkout/) a un paquete de python con DDD y TDD.

# Instalación del paquete


# Uso del paquete

